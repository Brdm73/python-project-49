#!/usr/bin/env python3
from ..games.prime import play_prime


def main():
    play_prime()


if __name__ == '__main__':
    main()

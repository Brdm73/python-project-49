#!/usr/bin/env python3
from ..games.progression import play_progression


def main():
    play_progression()


if __name__ == '__main__':
    main()

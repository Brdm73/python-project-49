### Hexlet tests and linter status:
[![Actions Status](https://github.com/Brdm73/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Brdm73/python-project-49/actions)

### CodeClimate
<a href="https://codeclimate.com/github/Brdm73/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/eb9eb9b853127994d518/maintainability" /></a>

### Asciinema brain-even:
<a href="https://asciinema.org/a/P6MbHoV9gYrySZGt6r5YKjndk"><img src="https://asciinema.org/a/14.png" width="836"/></a>

### Asciinema brain-calc:
<a href="https://asciinema.org/a/G5EgYhsRMUdRKv6fsceNTYk3T"><img src="https://asciinema.org/a/14.png" width="836"/></a>

### Asciinema brain-gtc:
<a href="https://asciinema.org/a/r3pMymrFG2yRpdeczYp5IBbJX"><img src="https://asciinema.org/a/14.png" width="836"/></a>

### Asciinema brain-progression:
<a href="https://asciinema.org/a/4WHg5DRkZmxBipsOKLmTtloc1"><img src="https://asciinema.org/a/14.png" width="836"/></a>


#!/usr/bin/env python3
from ..games.gcd import play_gcd


def main():
    play_gcd()


if __name__ == '__main__':
    main()

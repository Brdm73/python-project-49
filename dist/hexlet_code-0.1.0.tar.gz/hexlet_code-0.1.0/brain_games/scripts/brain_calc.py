#!/usr/bin/env python3

from ..games.calc import play_calc


def main():
    play_calc()


if __name__ == '__main__':
    main()
